package com.example.drawguess.model;

public class sqliteData {
    public int no;
    public String wordName;
    public String wordHint;
}
